# machineLearning
전공수업(기계학습) 에서 진행한 프로젝트입니다. 
python3로 진행하였고, Jupyter Notebook을 사용하여 기계학습에 필요한 python module을 이용해 완성하였습니다.

# detailed information
자세한 사항은 machine_learning_final_script 파일에 기술되어 있습니다.
