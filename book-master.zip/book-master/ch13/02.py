exam_dic = {'key1':'room1', 'key2':'room2'}

print(exam_dic['key1'])
print(exam_dic['key2'])
