kakao_daily_ending_prices = [92300, 94300, 92100, 92400, 92600]

for price in kakao_daily_ending_prices:
    print(price)