from pandas import Series, DataFrame

kakao = Series([92600, 92400, 92100, 94300, 92300])
print(kakao)

print(kakao[0])
print(kakao[2])
print(kakao[4])
