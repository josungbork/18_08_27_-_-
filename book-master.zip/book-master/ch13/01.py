mystock = ['kakao', 'naver']

print(mystock[0])
print(mystock[1])

for stock in mystock:
    print(stock)
