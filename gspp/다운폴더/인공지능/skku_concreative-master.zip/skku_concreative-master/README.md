# skku_concreative
인공지능 수리기초 연구회
