import math

class data(object):
	count = 0

	def __init__(self, p1, p2):
		self.dataList = p1
		self.result = p2
		data.count += 1
