# 패턴인식과 기계학습

## 교재
* [패턴 인식과 기계학습:기초부터 활용까지](http://www.yes24.com/24/goods/4723339?scode=032&OzSrank=2) - 박혜영, 이관용 저, 이한출판사

## 환경
* python3
* anaconda
