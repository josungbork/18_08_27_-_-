import win32com.clientTrue

explore = win32com.client.Dispatch("InternetExplorer.Application")
explore.Visible =